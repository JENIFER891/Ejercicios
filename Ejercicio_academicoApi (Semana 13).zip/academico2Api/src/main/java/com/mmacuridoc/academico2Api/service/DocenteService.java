package com.mmacuridoc.academico2Api.service;

import com.mmacuridoc.academico2Api.exception.GlobalExceptionHandler;
import com.mmacuridoc.academico2Api.model.Docente;
import com.mmacuridoc.academico2Api.repository.DocenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import com.mmacuridoc.academico2Api.exception.RecursoNoEncontradoException;


import java.util.List;

@Service
public class DocenteService {
//Instancia del repositorio, para el acceso a datos
    @Autowired
    private DocenteRepository repo;

    //Todos los docentes de la base de datos
    public List<Docente> listarTodos() {
        return repo.findAll();
    }

    //Docente por Id
    public Docente obtenerPorId(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No se encontró el docente con ID " + id));
    }

    //Docente por ciudad
    public List<Docente> obtenerPorCiudad(String ciudad) {
        List<Docente> docentes = repo.findByCiuDocente(ciudad);
        if (docentes.isEmpty()) {
            throw new RecursoNoEncontradoException("No se encontraron docentes en la ciudad: " + ciudad);
        }
        return docentes;
    }


    public Docente crear(Docente docente) {
        return repo.save(docente);
    }

    public Docente actualizar(Long id, Docente docente) {
        Docente actual = obtenerPorId(id);
        docente.setIdDocente(actual.getIdDocente());
        return repo.save(docente);
    }

    public void eliminar(Long id) {
        repo.deleteById(id);
    }

    public List<Docente> buscarPorCiudad(String ciudad) {
        return repo.findByCiuDocente(ciudad);
    }

    public List<Docente> buscarPorExperiencia(int anios) {
        return repo.findByTiempoServicioGreaterThanEqual(anios);
    }

    public Double calcularEdadPromedio() {
        return repo.calcularEdadPromedio();
    }

    public Page<Docente> listarPaginado(int page, int size) {
        return repo.findAll(PageRequest.of(page, size));
    }
}

