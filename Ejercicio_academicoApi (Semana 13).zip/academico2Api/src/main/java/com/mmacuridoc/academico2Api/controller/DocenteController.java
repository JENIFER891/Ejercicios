package com.mmacuridoc.academico2Api.controller;

import com.mmacuridoc.academico2Api.exception.GlobalExceptionHandler;
import com.mmacuridoc.academico2Api.model.Docente;
import com.mmacuridoc.academico2Api.service.DocenteService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/docentes")
public class DocenteController {
//para inyectar una instancia del servicio DocenteService
    @Autowired
    private DocenteService service;

    //Obtener todos los docentes
    @GetMapping
    public List<Docente> listar() {
        return service.listarTodos();
    }
    //Obtener un docente por su ID
    @GetMapping("/{id}")
    public Docente obtener(@PathVariable Long id) {
        return service.obtenerPorId(id);
    }

    //Crear un docente
    @PostMapping
    public Docente crear(@Valid @RequestBody Docente docente) {
        return service.crear(docente);
    }

    //Actualizar docente
    @PutMapping("/{id}")
    public Docente actualizar(@PathVariable Long id, @Valid @RequestBody Docente docente) {
        return service.actualizar(id, docente);
    }

    //Eliminar docente
    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }

    //Obtener docente por ciudad
    @GetMapping("/ciudad/{ciudad}")
    public List<Docente> obtenerCiudad(@PathVariable String ciudad) {
        return service.obtenerPorCiudad(ciudad);
    }

   //Obtener docente a partir de ciertos años de experiencia
  // @GetMapping("/experiencia/{anios}")
  // public ResponseEntity<?> porExperiencia(@PathVariable int anios) {
     //  if (anios < 0) {
      //     Map<String, String> error = new HashMap<>();
      //     error.put("error", "El número de años de experiencia no puede ser negativo");
       //    return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
     //  }

       //return ResponseEntity.ok(service.buscarPorExperiencia(anios));
   //}
    @GetMapping("/experiencia/{anios}")
    public ResponseEntity<?> porExperiencia(@PathVariable int anios) {
        if (anios < 0) {
            throw new GlobalExceptionHandler.ParametroInvalidoException("El número de años de experiencia no puede ser negativo");
        }

        return ResponseEntity.ok(service.buscarPorExperiencia(anios));
    }



    //Edad promedio de todos los docentes
    @GetMapping("/edad-promedio")
    public Double edadPromedio() {
        return service.calcularEdadPromedio();
    }

    //Devuelve los docentes paginados (ayuda cuando hay muchos registros)
    @GetMapping(params = {"page", "size"})
    public Page<Docente> paginacion(@RequestParam int page, @RequestParam int size) {
        return service.listarPaginado(page, size);
    }
}
