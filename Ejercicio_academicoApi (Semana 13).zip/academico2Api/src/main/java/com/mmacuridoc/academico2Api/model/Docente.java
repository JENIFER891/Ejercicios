package com.mmacuridoc.academico2Api.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Docente {

    @Id
    @Column(name = "id_docente")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idDocente;
//camilcase= nomDocente Java, snakecase= nom_Docente BD
    @Column(name = "nom_docente")
    @NotBlank(message = "El nombre no puede estar vacío")
    private String nomDocente;

    @Column(name = "dir_docente")
    @NotBlank(message = "La dirección no puede estar vacía")
    @Schema(description = "Direccion del docente", example = "calle garzas n°123")
    private String dirDocente;

    @Column(name = "ciu_docente")
    @NotBlank(message = "La ciudad no puede estar vacía")
    @Schema(description = "Ciudad del docente", example = "Lima")
    private String ciuDocente ;

    @Column(name = "email_docente")
    @Email(message = "Debe tener formato de correo")
    @NotBlank(message = "El email no puede estar vacío")
    @Schema(description = "Email del docente", example = "mayra@gmail.com")
    private String emailDocente ;

    @Column(name = "fec_nacimiento")
    @Past(message = "La fecha debe ser anterior a hoy")
    private LocalDate fecNacimiento;

    @Column(name = "tiempo_servicio")
    @Min(value = 0, message = "El tiempo de servicio no puede ser negativo")
    private int tiempoServicio;
}

