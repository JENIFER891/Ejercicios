package com.mmacuridoc.academico2Api.exception;

import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.util.*;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // Error general tipo RuntimeException
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> manejarIllegalArgument(IllegalArgumentException ex) {
        Map<String, String> error = new HashMap<>();

        if (ex.getMessage().toLowerCase().contains("page index must not be less than zero")) {
            error.put("error", "El número de página no puede ser negativo.");
        } else {
            error.put("error", ex.getMessage());
        }

        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }


    //  Errores de validación con @Valid
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> manejarValidaciones(MethodArgumentNotValidException ex) {
        Map<String, String> errores = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(err ->
                errores.put(err.getField(), err.getDefaultMessage())
        );
        return new ResponseEntity<>(errores, HttpStatus.BAD_REQUEST);
    }

    // Error formato de fecha
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, String>> manejarErrorFormato(HttpMessageNotReadableException ex) {
        Map<String, String> error = new HashMap<>();

        if (ex.getCause() instanceof com.fasterxml.jackson.databind.exc.InvalidFormatException) {
            error.put("error", "Formato inválido. Verifica que la fecha esté en el formato AAAA-MM-DD.");
        } else {
            error.put("error", "Error en el cuerpo de la solicitud. Verifica los datos enviados.");
        }

        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    // Manejo de parámetros inválidos (como años negativos)
    @ExceptionHandler(ParametroInvalidoException.class)
    public ResponseEntity<Map<String, String>> manejarParametroInvalido(ParametroInvalidoException ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    // Clase interna: Excepción personalizada
    public static class ParametroInvalidoException extends RuntimeException {
        public ParametroInvalidoException(String mensaje) {
            super(mensaje);
        }
    }

    // Error cuando se envía texto en lugar de número (por ejemplo, "abc" en vez de int)
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Map<String, String>> manejarTipoInvalido(MethodArgumentTypeMismatchException ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", "El valor '" + ex.getValue() + "' no es válido para el parámetro '" + ex.getName() +
                "'. Debe ser un número entero.");
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(RecursoNoEncontradoException.class)
    public ResponseEntity<Map<String, String>> manejarRecursoNoEncontrado(RecursoNoEncontradoException ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }



}


