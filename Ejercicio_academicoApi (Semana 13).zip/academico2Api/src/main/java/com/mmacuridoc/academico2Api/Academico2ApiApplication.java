package com.mmacuridoc.academico2Api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Academico2ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Academico2ApiApplication.class, args);
	}

}
