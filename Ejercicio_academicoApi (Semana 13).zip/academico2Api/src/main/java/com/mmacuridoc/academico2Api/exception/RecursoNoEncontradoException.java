package com.mmacuridoc.academico2Api.exception;

/**
 * Excepción personalizada para manejar casos donde no se encuentra un recurso (como un Docente).
 */
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}

