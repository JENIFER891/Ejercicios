package com.mmacuridoc.academico2Api.repository;

import com.mmacuridoc.academico2Api.model.Docente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface DocenteRepository extends JpaRepository<Docente, Long> {

    List<Docente> findByCiuDocente(String ciudad);
    // En DocenteRepository.java
    Optional<Docente> findFirstByCiuDocente(String ciudad);

    List<Docente> findByTiempoServicioGreaterThanEqual(int anios);

    @Query("SELECT AVG(YEAR(CURRENT_DATE) - YEAR(d.fecNacimiento)) FROM Docente d")
    Double calcularEdadPromedio();


}
