package com.mmacuridoc.academico2Api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Academico2ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
