import React from 'react';
import ComponentGeneral from './components/ComponentGeneral';

function App() {
  return <ComponentGeneral />;
}

export default App;
