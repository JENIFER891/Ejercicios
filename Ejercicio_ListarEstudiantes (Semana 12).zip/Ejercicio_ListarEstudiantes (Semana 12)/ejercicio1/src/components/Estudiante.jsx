import React from 'react';
import './Estudiante.css';
import avatar from '../assets/default-avatar.png';

const Estudiante = ({ estudiante }) => {
  return (
<div className="id-card">
  <div className="card-header">
    <div className="logo-section">
      <div className="logo">🎓</div>
      <div className="university-name">UNIVERSITY NAME</div>
    </div>
    <div className="title">STUDENT ID CARD</div>
  </div>

<div className="card-body">
  <img src={avatar} alt="Foto estudiante" className="student-photo" />
  <div className="info">
    <h2 className="student-name">{estudiante.name}</h2>
    <p><strong>Student Id:</strong> {estudiante.id}</p>
    <p><strong>Date:</strong> {estudiante.birthdate}</p>
    <p><strong>Address:</strong> {estudiante.address}</p>
  </div>
</div>


  <div className="barcode">{estudiante.id}</div>
</div>

  );
};

export default Estudiante;

