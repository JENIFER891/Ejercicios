import React from 'react';
import Estudiante from './Estudiante';
import './ListaEstudiantes.css';

const ListaEstudiantes = ({ estudiantes }) => {
  return (
    <div className="lista-estudiantes">
      {estudiantes.map((est) => (
        <Estudiante key={est.id} estudiante={est} />
      ))}
    </div>
  );
};

export default ListaEstudiantes;
