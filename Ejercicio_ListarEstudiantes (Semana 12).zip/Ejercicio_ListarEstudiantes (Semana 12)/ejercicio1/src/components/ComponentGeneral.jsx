import React, { useEffect, useState } from 'react';
import ListaEstudiantes from './ListaEstudiantes';
import estudiantesData from '../assets/estudiantes.json';

const ComponentGeneral = () => {
  const [estudiantes, setEstudiantes] = useState([]);

  useEffect(() => {
    setEstudiantes(estudiantesData);
  }, []);

  return (
    <div>
      <h1>Lista de Estudiantes</h1>
      <ListaEstudiantes estudiantes={estudiantes} />
    </div>
  );
};

export default ComponentGeneral;
