import pymysql 

def obtener_conexion():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='fiorella12345',
        db='escuela',
        cursorclass=pymysql.cursors.DictCursor
    )

def inicializar_db():
    conexion = obtener_conexion()
    try:
        with conexion.cursor() as cursor:
            # Crear tabla de usuarios si no existe
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS usuarios (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(50) NOT NULL UNIQUE,
                    password VARCHAR(255) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            # Crear tabla de estudiantes si no existe (por si acaso)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS estudiantes (
                    IdEstudiante INT AUTO_INCREMENT PRIMARY KEY,
                    nomEstudiante VARCHAR(100),
                    dirEstudiante VARCHAR(150),
                    ciuEstudiante VARCHAR(100)
                )
            """)
        conexion.commit()
    finally:
        conexion.close()

# Ejecutar al importar
inicializar_db()